import 'package:flutter/material.dart';

class ChatMessage {
  String? message;
  String? messageType;
  ChatMessage({@required this.message, @required this.messageType});
}
